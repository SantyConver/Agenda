/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jx.pruebajdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *?useSSL=false&useTimezone=true&serverTimezone=UTC&allowPublicKeyRetrieval=true
 * @author Juan Cruz
 */
public class Prueba {
    public static void main(String[] args){
        
        String url = "jdbc:mysql://localhost:3307/pruebajdbc";
        
        
         
           
        
        
        try {
            Connection conexion = DriverManager.getConnection(url, "juan2", "juan2");
            Statement st = conexion.createStatement();
            //----- hasta aca seria bastante generico ---//
            ResultSet rs = st.executeQuery("SELECT * FROM persona");
            
            while(rs.next()){
            
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Nombre: " + rs.getString("nombre"));
                System.out.println("Apelldio: " + rs.getString("apellido"));
                
                System.out.println("email: " + rs.getString("email"));
                
            
            
            }
            rs.close();
            st.close();
            conexion.close();
            
            
        } catch (SQLException ex) {
           ex.printStackTrace(System.out);
        }
        
        
    }
}
